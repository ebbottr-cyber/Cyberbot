"""Run with Python 3.11+: python kripto_fiyatlarini_yenile.py"""
import json
import tempfile
import time
import urllib.request
from pathlib import Path
from urllib.error import HTTPError
from datetime import datetime, timezone

def fetch(url, path):
    for attempt in range(4):
        try:
            request = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(request, timeout=25) as response:
                data = json.load(response)
            path.write_text(json.dumps(data), encoding="utf-8")
            return data
        except HTTPError as error:
            if error.code != 429 or attempt == 3:
                raise
            delay = error.headers.get("Retry-After", "")
            time.sleep(int(delay) if delay.isdigit() else 30)

def download(folder):
    for i, url in enumerate(("https://fapi.binance.com/fapi/v1/", "https://dapi.binance.com/dapi/v1/")):
        for endpoint, prefix in (("exchangeInfo", "ebinfo"), ("ticker/24hr", "ebprices"), ("ticker/bookTicker", "ebbook")):
            fetch(url + endpoint, folder / f"{prefix}{i}")
    for i, feed in ((2, "new_pools"), (3, "trending_pools")):
        for page in range(1, 11):
            name = f"ebprices{i}" if page == 1 else f"ebsol{i}_{page}"
            data = fetch(f"https://api.geckoterminal.com/api/v2/networks/solana/{feed}?page={page}", folder / name)
            if len(data["data"]) < 20:
                break
            time.sleep(7)

import csv,json,zipfile,io
from datetime import datetime,timezone
from pathlib import Path
from collections import Counter
UTC=timezone.utc
def iso(t):return datetime.fromtimestamp(t,UTC).isoformat(timespec='seconds')
def build(folder, output):
    def read(p):return json.loads((folder / p).read_text())
    def stamp(p):return iso((folder / p).stat().st_mtime)
    def write(name,rows):
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            label = row.get("name", "")
            if label.lstrip().startswith(("=", "+", "-", "@")):
                row = dict(row, name="'" + label)
            writer.writerow(row)
        z.writestr(name, buf.getvalue().encode("utf-8-sig"))
    summary={}
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
     for i,market in enumerate(['USD-M','COIN-M']):
      path=f'ebprices{i}';bp=f'ebbook{i}';tick={x['symbol']:x for x in read(path)};books={x['symbol']:x for x in read(bp)};rows=[]
      for x in read(f'ebinfo{i}')['symbols']:
       if x.get('status',x.get('contractStatus'))!='TRADING' or x['underlyingType'] not in ('COIN','PREMARKET') or 'TradFi' in x.get('underlyingSubType', []):continue
       t=tick[x['symbol']];b=books.get(x['symbol'],{}); assert float(t['lastPrice'])>0
       rows.append(dict(symbol=x['symbol'],base=x['baseAsset'],quote=x['quoteAsset'],margin=x['marginAsset'],category=x['underlyingType'],contract=x['contractType'],contract_size=x.get('contractSize'),last=t['lastPrice'],bid=b.get('bidPrice'),ask=b.get('askPrice'),book_time_utc=iso(b['time']/1000) if b.get('time') else None,ticker_close_utc=iso(t['closeTime']/1000),ticker_collected_utc=stamp(path),book_collected_utc=stamp(bp),change_24h_pct=t['priceChangePercent'],high_24h=t['highPrice'],low_24h=t['lowPrice'],base_volume_24h=t.get('baseVolume',t['volume']),quote_volume_24h=t.get('quoteVolume'),contracts_volume_24h=t['volume'] if i else None,trades_24h=t['count']))
      write(market+'.csv',rows);summary[market]={'contracts':len(rows),'bid_ask_count':sum(bool(r['bid'] and r['ask']) for r in rows),'categories':dict(Counter(r['category'] for r in rows))}
     for i,label in [(2,'new_pools'),(3,'trending_pools')]:
      rows={};files=[Path(f'ebprices{i}')]+sorted(folder.glob(f'ebsol{i}_*'),key=lambda p:int(p.name.split('_')[-1]))
      for page,p in enumerate(files,1):
       for o in read(p)['data']:
        a=o['attributes'];rels=o['relationships'];addr=a['address']
        if addr in rows:continue
        rows[addr]=dict(pool=addr,name=a['name'],dex=rels['dex']['data']['id'],base_mint=rels['base_token']['data']['id'].removeprefix('solana_'),quote_mint=rels['quote_token']['data']['id'].removeprefix('solana_'),base_price_usd=a.get('base_token_price_usd'),quote_price_usd=a.get('quote_token_price_usd'),liquidity_usd=a.get('reserve_in_usd'),volume_24h_usd=a['volume_usd'].get('h24'),change_1h_pct=a['price_change_percentage'].get('h1'),change_24h_pct=a['price_change_percentage'].get('h24'),buys_24h=a['transactions']['h24']['buys'],sells_24h=a['transactions']['h24']['sells'],created_utc=a['pool_created_at'],collected_utc=stamp(p),page=page)
      write(label+'.csv',list(rows.values()));summary[label]=dict(pages=len(files),pools=len(rows),priced=sum(bool(r['base_price_usd'] and float(r['base_price_usd'])>0) for r in rows.values()))
     z.writestr('kaynaklar.json',json.dumps(dict(summary=summary,binance=['https://fapi.binance.com/fapi/v1/','https://dapi.binance.com/dapi/v1/'],endpoints=['exchangeInfo','ticker/24hr','ticker/bookTicker'],solana='https://api.geckoterminal.com/api/v2/networks/solana/',note='UTC. Binance last is last trade; book and rolling 24h snapshots are asynchronous. Solana rows are pool-level provider discovery lists, collected_utc is retrieval time. Empty fields mean unavailable.'),indent=2))
    print(summary)
if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as temp:
        folder = Path(temp)
        download(folder)
        output = Path.cwd() / ("EBBot_Kripto_Solana_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".zip")
        temporary = folder / "result.zip"
        build(folder, temporary)
        import shutil
        shutil.copyfile(temporary, output)
        print(output)
